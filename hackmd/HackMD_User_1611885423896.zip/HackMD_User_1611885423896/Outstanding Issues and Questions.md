---
tags: argo-pl
title: Outstanding Issues and Questions
---

[![hackmd-github-sync-badge](https://hackmd.io/lTCJhuj6Rfa84-WhMmi90g/badge)](https://hackmd.io/lTCJhuj6Rfa84-WhMmi90g)


{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Outstanding Issues and Questions

[TOC]

## FAQ

{%hackmd fIVmWXSnSYeTUeCno9umnw %}


## Proposed Changes to the Base FHIR Specification

- [FHIR-27083](https://jira.hl7.org/browse/FHIR-28291)
- [FHIR-23724](https://jira.hl7.org/browse/FHIR-28291)
- [FHIR-28208](https://jira.hl7.org/browse/FHIR-28291)
- [FHIR-28291](https://jira.hl7.org/browse/FHIR-28291)


## Connectathon Issues

- QuestionnaireResponse Search not working per spec on the HAPI server: https://chat.fhir.org/#narrow/stream/179167-hapi/topic/QuestionnaireResponse.20questionnaire.20SP
- [Connectathon 26 issues](https://hackmd.io/13214aLMQrW4-lYWYSYgUQ#Issues)

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}