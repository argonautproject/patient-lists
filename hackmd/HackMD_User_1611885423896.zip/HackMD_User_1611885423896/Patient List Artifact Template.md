---
tags: argo-pl
title: Patient List Artifact Template
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut Patient List [artifact name]

[TOC]

[intro]

 ## Mandatory and Must Support Data Elements

  The following data-elements are mandatory (i.e data MUST be present) or must be supported if the data is present in the source system. They are presented below in a simple human-readable explanation.  Profile specific guidance and examples are provided as well.  The StructureDefinition and its rendering provides a summary, tree views, definitions, and terminology requirements.

## Profile specific implementation guidance:

  * foo

## Formal Definition
Rendered output [ArgonautPatientList[profilename]](https://argonautproject.github.io/patient-lists/StructureDefinition-[profile id].html#profile)


<iframe src="https://argonautproject.github.io/patient-lists/StructureDefinition-[profile id].html#profile" width="100%" height="500">
</iframe>

YAML representation of the argo-patientlist resource profile.

{%gist Healthedata1/5ae0c565e4d7050cebf478f9e7f493ae%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}

## Examples

- [Example 1](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 2](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 3](/u8iAyzZ0SGahQdbVzYpfoQ)
