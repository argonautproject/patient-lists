---
tags: argo-pl
title: Publishing Punch list
---
{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Publishing Punch list



```mermaid
gantt
    title Publishing Roadmap

    section Publish
    Final Content Edits          :a1, 2021-01-015, 14d
    Open Comment period    :a2, 2021-01-015  , 28d
    Final QA    :a3, after a2  , 7d
    Publish!!    :after a3  , 7d
```

## Sections to Complete

- [X] conformance/capability statement
    - [X] Client
        - [X] fix searchparameters references
    - [X] Server ...
    - [X] $getpage operation
 
## PostMan Example API Documentation

-  [X] post on postman network
-  [ ] use argonaut hosted domain
    -  [ ] discuss with Josh and team
- [ ] create download for local viewing
   > (from SO) You can export the collection as a json as shown in the other answer and then run a tool to convert it into an HTML document that you can host wherever you want.
  > I created a simple python executable to do just that - https://github.com/karthiks3000/postman-doc-gen
- [ ] add argo icons - todo

## Save all HACKMd notes on GitHub

- [ ] consider moving content to GitHub - less efficient losing some of the advantages of HACKmd

## Editorial QA

- [ ] QA Read through

## Publish Book Mode

- [ ] publish in book mode
    - [ ] use argonaut hosted domain ( git pages?? )
    - [ ] use argonaut hosted HACKMD site ??

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}