---
tags: argo-pl
title: Terminology
---
{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

{%hackmd fIVmWXSnSYeTUeCno9umnw %}

# Terminology

- [Argonaut User Facing Patient List Characteristic Codes](/lNNapOQPQeOoiRNEb0cjSQ)



{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}