---
tags: argo-pl
title: Operations
---
{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

{%hackmd fIVmWXSnSYeTUeCno9umnw %}

# Operations

- [$getpage Operation](/u8iAyzZ0SGahQdbVzYpfoQ)

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}
