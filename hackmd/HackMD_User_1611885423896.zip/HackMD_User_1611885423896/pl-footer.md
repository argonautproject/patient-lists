---
tags: argo-pl
title: pl-footer
---

---

- [name=erichaas]
- [time=Fri, Sep 18, 2020 2:34 PM]
- [Argonaut Patient Lists GitHub Repro](https://github.com/argonautproject/patient-lists)