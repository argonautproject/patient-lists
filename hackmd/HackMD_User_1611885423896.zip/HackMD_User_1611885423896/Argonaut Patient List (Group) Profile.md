---
tags: argo-pl
title: Argonaut Patient List (Group) Profile
---
{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut User Facing Patient List (Group) Profile

:::success
URL
`http://www.fhir.org/guides/argonaut/patient-list/StructureDefinition/patientlist`
:::

[TOC]

This profile sets minimum expectations for the [Group](http://hl7.org/fhir/group.html) resource to record, search, and fetch user-facing patient lists. It identifies the core mandatory and must support and optional elements, extensions, vocabularies and value sets which SHALL be present in the Group resource when using this profile. The formal StructureDefinition and its rendering provides a summary, tree views, definitions, and terminology requirements. Specific guidance and examples are documented as well. 

 ## Mandatory, Must Support, and Optional Elements

The core patient list Group elements are presented below. They are divided into 1) mandatory elements which **SHALL** always be present, 2) *must support* elements which **SHALL** be present if the data is present in the source system, or 3) optional elements which **MAY** be present.  The guidance and expections behavior for these three conformance levels is detailed in the [Conformance Expectations](/2jerAwtsQvGA7G-bZpQ1BA) section. 

  **Each Group MUST have:**

  1.  a type of "person"
  1.  a actual marked as "true" to indicate it a list of real patients

  **Each Group MUST SUPPORT:**

  1. the number of members in the patient list
  1. a reference to the practitioner or organization managing the list*
  1. one or more references to the patients who make up the patient list

**Each Group MAY have:**
  
  1. the [Argonaut User Facing Patient List Questionnaire Extension](/RgP-iegaTASWxO00CKXeEA?both)
  1. one or more characteristic codes that define the patient list
  1. the [Argonaut User Facing Patient List  Member QuestionnaireResponse Extension](/nswM55USQZWXERNSqBxBug)
  1. the [Argonaut User Facing Patient List Member Appointment Extension](/ftDJ06TPRnSTCIr2fBPBpQ)
  1. the [Argonaut User Facing Patient List Member Encounter Extension](/pLpthchtTGWjt4hqLwU8Kg)
  

## Profile specific implementation guidance:

  * \* The `managingEntity` element differentiates between user-maintained and system-maintained lists.  Additionally, the [Provenance](http://hl7.org/fhir/provenance.html) resource could be used to provide more details about patient list creation and management.

  * \* The difference between the `managingEntity` element and the characteristic code="organization" is that the former is the patient list custodian and the latter is the organization provding care to the patients listed in 'Group.member'.  For example, *Acme Health* could be the managing entity and *Acme Health Wisconsin* or *Acme Health Wisconsin* could be the organization characteristic value.

  * Groups with different characteristics can be combined to create a union of characteristics. For example, Group/3 in the table below has as its members Group/1 and Group/2 which are in turn composed of  patients that meet the characteristic criteria of Location/1 and Location/2.
      
      |Group|Group.characteristic|Group.member|
      |---|---|---|
      |Group/1|location = Location/1|Patient/n...Patient/m|
      |Group/2|location = Location/2|Patient/x...Patient/y|
      |Group/3|none|Group/1,Group/2|
      
  * This profile restricts the references to the practitioner or organization managing the list and the patients who make up the patient list to FHIR resource ids.  Providing *only* a business or other identifier as a logical reference to the entity of the target resource is not supported.


    In other words, this is valid:
    :::success
    ...
      "managingEntity": {
        "reference": "Organization/e002090d-4e92-300e-b41e-7d1f21dee4c6",
        "display": "CAMBRIDGE HEALTH ALLIANCE"
      },
    ...
    :::

    ... this is not:
    :::danger
    "managingEntity": {
        "identifier": {"value" : "urn:uuid:002090d-4e92-300e-b41e-7d1f21dee4c6"},
        "display": "CAMBRIDGE HEALTH ALLIANCE"
      },
    :::


## Formal Definition
Rendered output [ArgonautPatientListProfile](https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist.html#profile)


<iframe src="https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist.html#profile" width="100%" height="500">
</iframe>

YAML representation of the argo-patientlist resource profile.

{%gist Healthedata1/5ae0c565e4d7050cebf478f9e7f493ae%}


## Examples

[Example in Postman](https://documenter.getpostman.com/view/1447203/TVssjTjT#d9ca0bd9-b98a-4e0a-a056-5800f83119ac) :arrow_upper_right:

additional [Examples and Test Data](/aMgcWmFeRMiSMxfq-S7xZA) for download are also avaible.

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}