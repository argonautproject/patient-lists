---
tags: argo-pl
title: Profiles and Extensions
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

{%hackmd fIVmWXSnSYeTUeCno9umnw %}

# Profiles and Extensions

## Profiles
- [Argonaut User Facing Patient List Group Profile](/LFIGMBDXTR-TpJ2Dt6JOxQ)
<!--
- [Argonaut Patient List Questionaire Profile](/u8iAyzZ0SGahQdbVzYpfoQ)
-->

## Extensions

- [Argonaut User Facing Patient List Member Appointment Extension](/ftDJ06TPRnSTCIr2fBPBpQ)
- [Argonaut User Facing Patient List Member Encounter Extension](/pLpthchtTGWjt4hqLwU8Kg)
- [Argonaut User Facing Patient List Questionnaire Extension](/RgP-iegaTASWxO00CKXeEA)
- [Argonaut User Facing Patient List  Member QuestionnaireResponse Extension](/nswM55USQZWXERNSqBxBug)

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}