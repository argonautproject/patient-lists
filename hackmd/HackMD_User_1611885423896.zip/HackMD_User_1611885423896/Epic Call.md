---
tags: argo-pl
---

# Epic Call

Streaming?  not saved??

Panoptic view

Use BackEnd Services for OAUth

Heavy

Paging considerations

see what happens when lists gets large

how to page to make responsive see chat.

QR updates - use lastupdated so can be updated

polling group and questionniare.

QR on the fly vs stored

rendering issues.

more notes here:

https://docs.google.com/document/d/1Cbj79sp-62uylt8wxDk85Ke_QlzqJvf8WyLFrffvPDk/edit?pli=1#heading=h.1kmipvvmsh8c

Next Step Oct 28th presentation


