---
tags: argo-pl
title: Patient List Server CapabilityStatement
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut User Facing Patient List Server CapabilityStatement

[TOC]

## Formal Definition
Rendered output [User Facing Patient List Server CapabilityStatement](https://argonautproject.github.io/patient-lists/CapabilityStatement-server.html)

<iframe src="https://argonautproject.github.io/patient-lists/CapabilityStatement-server.html" width="100%" height="500">
</iframe>

YAML representation of the Server CapabilityStatement


{%gist Healthedata1/283f9eecea509b74f393801ad7a85c87%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}
