---
tags: argo-pl
title: Why Group
---

:::info
This project uses the FHIR *Group* resource to represent user facing patient lists ([see why](https://hackmd.io/I31aiRZhSVWo2eidxrGZ4g#The-Group-Resource)).
:::

