---
tags: argo-pl
title: Argonaut Patient List  Member QuestionnaireResponse Extension
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut Patient List  Member QuestionnaireResponse Extension
:::success
URL
`http://www.fhir.org/guides/argonaut/patient-list/StructureDefinition/patientlist-questionnaireresponse`
:::

[TOC]

An EHR **MAY** defines additional data for the members in a Patient List using a FHIR [Questionnaire](http://hl7.org/fhir/questionnaire.html)  based on the [SDC Base Questionnaire](https://build.fhir.org/ig/HL7/sdc/StructureDefinition-sdc-questionnaire.html) profile.  This extension references the [QuestionnaireResponse](http://hl7.org/fhir/questionnaireresponse.html) resource that represents the completed answers to the Questionnaire for a `Group.member`. The client app can use the reference to retrieve the data.  Note that typically the EHR and not the patient supplies the responses to the Questionnaire. The [Argonaut Patient List Questionnaire Extension](/RgP-iegaTASWxO00CKXeEA?both) extension provides a corresponding link to the Questionnaire.

 ## Mandatory and Must Support Data Elements

  The following data-elements are mandatory (i.e data MUST be present)
  
1. Extension url
1. Reference to the QuestionnaireResponse

## Where this Extension is used:

  * Group.member element

## Formal Definition
Rendered output [ArgonautPatientList[profilename]](https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-questionnaireresponse.html#profile)


<iframe src="https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-questionnaireresponse.html#profile" width="100%" height="500">
</iframe>

YAML representation:

{%gist Healthedata1/cca830395307b4ab8f3d05af1e7db18c%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}

## Examples

- [Example 1](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 2](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 3](/u8iAyzZ0SGahQdbVzYpfoQ)
