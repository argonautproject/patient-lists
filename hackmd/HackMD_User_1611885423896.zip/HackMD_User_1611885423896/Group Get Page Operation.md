---
tags: argo-pl
title: Group Get Page Operation
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Group Get Page Operation ($getpage)

[TOC]

## Formal Definition
Rendered output [Group Get Page Operation ($getpage)](https://argonautproject.github.io/patient-lists/OperationDefinition-getpage.html)

<iframe src="https://argonautproject.github.io/patient-lists/OperationDefinition-getpage.html" width="100%" height="500">
</iframe>

YAML representation of the Group Get Page Operation


{%gist Healthedata1/c443d3f66cd78655c55ce73d1a7e926a %}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}
