---
tags: argo-pl
title: Patient List Client CapabilityStatement
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut User Facing Patient List Client CapabilityStatement

[TOC]

## Formal Definition
Rendered output [User Facing Patient List Client CapabilityStatement](https://argonautproject.github.io/patient-lists/CapabilityStatement-client.html)

<iframe src="https://argonautproject.github.io/patient-lists/CapabilityStatement-client.html" width="100%" height="500">
</iframe>

YAML representation of the Client CapabilityStatement


{%gist Healthedata1/24d4ab14321cb407f81e51a3ec4e8092%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}
