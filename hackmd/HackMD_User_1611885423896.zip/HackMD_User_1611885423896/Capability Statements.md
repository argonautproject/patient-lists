---
tags: argo-pl
title: Capability Statements
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

{%hackmd fIVmWXSnSYeTUeCno9umnw %}

# Capability Statements
- [Argonaut User Facing Patient List Server CapabilityStatement](/qFa4Tb5aSh-UjeVGCAbaZA)
- [Argonaut User Facing Patient List Client CapabilityStatement](/mEXIEhOKRCm0Vmv9tODj0Q)

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}
