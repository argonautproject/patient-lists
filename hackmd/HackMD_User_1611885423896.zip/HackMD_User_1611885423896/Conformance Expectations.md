---
tags: argo-pl
title: Conformance Expectations
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

{%hackmd fIVmWXSnSYeTUeCno9umnw %}

# Conformance Expectations

This section outlines important definitions, interpretations, and requirements common to all Patient list actors used in this guide:

- The conformance verbs - **SHALL**, **SHOULD**, **MAY** - used in this guide are defined in [FHIR Conformance Rules](http://hl7.org/fhir/R4/conformance-rules.html#conflang).
- The [Capability Statements](/noBVQdkpS1iFJ7GmpM-0yQ) page outlines conformance requirements and expectations for the Argonaut User Facing Patient List EHR Servers and Client applications, identifying the specific profiles and RESTful transactions that need to be supported. 

    :::info
    
    Profiles identify the structural constraints, terminology bindings and invariants. Similarly, SearchParameters specify how they are understood by the server. However, implementers must refer to the CapabilityStatement for details on the RESTful transactions, specific profiles and the search parameters applicable to the Server and Client.
    :::

- The[ US Core Conformance Expectations](http://build.fhir.org/ig/HL7/US-Core/conformance-expectations.html) page defines the rules for interpreting profile elements and sub-elements labeled as [*Mandatory*](http://hl7.org/fhir/R4/profiling.html#cardinality), [*Must Support*](http://hl7.org/fhir/R4/profiling.html#mustsupport) and [*Optional*](http://hl7.org/fhir/R4/profiling.html#cardinality) for patient list Clients and Servers.

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}