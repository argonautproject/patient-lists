# Template todos

- [ ] fix template publishing issues
  - [X] add heading to Notes in ig.base
  - [ ] default to diff View
  - [X] hide example tab
  - [X] hide toc when not needed for markdown pages
  - [ ] add copy button
  - [X] hide constraints when empty
  - [X] smooth transitions
  - [X] down load and external reference icons
  - [X] ***fix Section  numbering ****
  - [X] create snapshot for current build
  - [X] update master with latest changes