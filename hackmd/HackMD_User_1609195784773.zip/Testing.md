---
tags: argo-pl
title: Testing
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Testing

- [Connectathon 25](https://confluence.hl7.org/display/FHIR/2020-09+Argonaut+Patient+Lists?src=contextnavpagetreemode)
    - [Argo Patient List Summary Slides](/DRTZx4jlRIWqpean8sLVEQ?edit)
- [Connectathon 26](https://confluence.hl7.org/display/FHIR/2021-01+Argonaut+Patient+Lists?src=contextnavpagetreemode)


{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}