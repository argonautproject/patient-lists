---
tags: argo-pl
title: Argonaut Patient List Member Appointment Extension
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut Patient List Member Appointment Extension
:::success
URL
`http://www.fhir.org/guides/argonaut/patient-list/StructureDefinition/patientlist-appointment`
:::

[TOC]

Some patient lists are defined by a specific appointment such as an list of patients being seen today. For these types of patient lists, an EHR **MAY** supply a reference to a specific [Appointment](http://hl7.org/fhir/appointment.html) that is the *reason* the target patient is a member of this patient list.  This extension references the relevant Appointment resource for a `Group.member` so the client app can retrieve it.

 ## Mandatory and Must Support Data Elements

  The following data-elements are mandatory (i.e data MUST be present)
  
1. Extension url
1. Reference to an Appointment

## Where this Extension is used:

  * Group.member element


## Formal Definition
Rendered output [Argonaut Patient List Member Appointment Extension](https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-appointment.html#profile)


<iframe src="https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-appointment.html#profile" width="100%" height="500">
</iframe>

YAML representation:

{%gist Healthedata1/6e96304fd9bd74005f9a0b3189c00b57%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}

## Examples

- [Example 1](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 2](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 3](/u8iAyzZ0SGahQdbVzYpfoQ)
