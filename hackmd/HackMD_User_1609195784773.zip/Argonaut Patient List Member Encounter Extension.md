---
tags: argo-pl
title: Argonaut Patient List Member Encounter Extension
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut Patient List Member Encounter Extension
:::success
URL
`http://www.fhir.org/guides/argonaut/patient-list/StructureDefinition/patientlist-encounter`
:::

[TOC]

Some patient lists are defined by a specific encounter such as an admission list or a discharge list. For these types of patient lists, an EHR **MAY** supply a reference to a specific [Encounter](http://hl7.org/fhir/encounter.html) that is the *reason* the target patient is a member of this patient list.  This extension references the relevant Encounter resource for a `Group.member` so the client app can retrieve it.  The Encounter resource is based on the [US Core Encounter](http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter) profile.

 ## Mandatory and Must Support Data Elements

  The following data-elements are mandatory (i.e data MUST be present)
  
1. Extension url
1. Reference to an Encounter

## Where this Extension is used:

  * Group.member element


## Formal Definition
Rendered output [Argonaut Patient List Member Encounter Extension](https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-encounter.html#profile)


<iframe src="https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-encounter.html#profile" width="100%" height="500">
</iframe>

YAML representation:

{%gist Healthedata1/5648e9cbae92c04e80adb51de60f31b1%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}

## Examples

- [Example 1](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 2](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 3](/u8iAyzZ0SGahQdbVzYpfoQ)
