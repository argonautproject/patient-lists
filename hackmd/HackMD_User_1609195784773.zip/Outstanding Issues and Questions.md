---
tags: argo-pl
title: Outstanding Issues and Questions
---

[![hackmd-github-sync-badge](https://hackmd.io/lTCJhuj6Rfa84-WhMmi90g/badge)](https://hackmd.io/lTCJhuj6Rfa84-WhMmi90g)


{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Outstanding Issues and Questions

[TOC]


## Proposed Changes to the Base FHIR Specification

[todo](/u8iAyzZ0SGahQdbVzYpfoQ)

## Connectathon Issues

- QuestionnaireResponse Search not working per spec on the HAPI server: https://chat.fhir.org/#narrow/stream/179167-hapi/topic/QuestionnaireResponse.20questionnaire.20SP

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}