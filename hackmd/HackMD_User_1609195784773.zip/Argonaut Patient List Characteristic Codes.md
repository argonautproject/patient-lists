---
tags: argo-pl
title: Argonaut Patient List Characteristic Codes

---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut Patient List Characteristic Codes

[TOC]


Initial set of group characteristic concepts for defining and searching for patient lists.

{%hackmd MX4laxCtQ3SOYVI2aOTcIw %}

## Formal Definition
Rendered output [Argonaut Patient List Characteristic Codes
](https://argonautproject.github.io/patient-lists/ValueSet-argo-group-characteristic.html)


<iframe src="https://argonautproject.github.io/patient-lists/ValueSet-argo-group-characteristic.html#expansion" width="100%" height="500">
</iframe>

YAML representation:

{%gist Healthedata1/df87a4b48e347378e7822edefcd3c204%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}
