---
tags: argo-pl
title: Argonaut Patient List Questionnaire Extension
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut Patient List Questionnaire Extension

:::success
URL
`http://www.fhir.org/guides/argonaut/patient-list/StructureDefinition/patientlist-questionnaire`
:::

[TOC]

An EHR **MAY** defines additional data for the members in a Patient List using a FHIR [Questionnaire](http://hl7.org/fhir/questionnaire.html)  based on the [SDC Base Questionnaire](https://build.fhir.org/ig/HL7/sdc/StructureDefinition-sdc-questionnaire.html) profile.  This extension references the Questionnaire resource so the client app can retrieve it. The [Argonaut Patient List  Member QuestionnaireResponse Extension](/nswM55USQZWXERNSqBxBug) extension provides a corresponding link to the completed answers to the Questionnaire for a `Group.member`.  Note that typically the EHR and not the patient supplies the responses to the Questionnaire.

 ## Mandatory and Must Support Data Elements

  The following data-elements are mandatory (i.e data MUST be present)
  
1. Extension url
1. Reference to the Questionnaire

## Where this Extension is used:

  * Group element

## Formal Definition
Rendered output [Argonaut Patient List Questionnaire Extension](https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-questionnaire.html#profile)


<iframe src="https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist-questionnaire.html#profile" width="100%" height="500">
</iframe>

YAML representation:
{%gist Healthedata1/bfc7088cbb556c8da8a3c6e73db4cdd4%}

## Examples

- [Example 1](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 2](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 3](/u8iAyzZ0SGahQdbVzYpfoQ)

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}


