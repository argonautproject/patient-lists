---
tags: argo-pl
title: Publishing Punch list
---
{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Publishing Punch list

## Sections to Complete

## PostMan Example API Documentation

-  [X] post on postman network
-  [ ] use argonaut hosted domain
    -  [ ] discuss with Josh and team
- [ ] create download for local viewing
   > (from SO) You can export the collection as a json as shown in the other answer and then run a tool to convert it into an HTML document that you can host wherever you want.
  > I created a simple python executable to do just that - https://github.com/karthiks3000/postman-doc-gen
- [ ] add icons - todo

## Move content to GitHub

- [ ] Move content to GitHub

## Editorial QA

- [ ] QA Read through

## Publish Book Mode

- [ ] publish in book mode
    - [ ] use argonaut hosted domain ( git pages?? )

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}