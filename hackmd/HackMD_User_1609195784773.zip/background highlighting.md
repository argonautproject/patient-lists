# background highlighting

:::success
Success!
:::

:::info
info.
:::

:::warning
Warning!
:::

:::danger
DANGER!!!
:::





