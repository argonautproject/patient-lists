---
tags: argo-pl
title: Group valueReference Search Parameter
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Group valueReference Search Parameter

[TOC]

This custom SearchParameter defines searching the [Group](http://hl7.org/fhir/group.html) resource by a `Group.characteristic.valueReference` element value. It is used *in combination* with the standard `characteristic`  search parameter to query for Groups by characteristics that use valueReference values as described in the [Discovery of User-Facing Lists](/2Rs6Y0hQSMGdt3kImASuZg) section.

Example usage:

~~~http
   GET Group?_summary=true&type=person&characteristic=[Code value]&value-reference=[valueReference value]
~~~

## Formal Definition
Rendered output [ArgonautPatientList[profilename]](https://argonautproject.github.io/patient-lists/SearchParameter-Group-value-reference.html)


<iframe src="https://argonautproject.github.io/patient-lists/SearchParameter-Group-value-reference.html#root" width="100%" height="500">
</iframe>

YAML representation:

{%gist Healthedata1/747030987dedd22020a66bc42940d39c%}

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}

## Examples

- [Example 1](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 2](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 3](/u8iAyzZ0SGahQdbVzYpfoQ)
