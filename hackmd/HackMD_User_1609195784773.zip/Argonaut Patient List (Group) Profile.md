---
tags: argo-pl
title: Argonaut Patient List (Group) Profile
---

{%hackmd 6-QbndXFTIaPJVymLK9qdw %}

# Argonaut Patient List (Group) Profile

:::success
URL
`http://www.fhir.org/guides/argonaut/patient-list/StructureDefinition/patientlist`
:::

[TOC]

This profile sets minimum expectations for the [Group](http://hl7.org/fhir/group.html) resource to record, search, and fetch user-facing patient lists. It identifies the [mandatory](http://build.fhir.org/ig/HL7/US-Core/conformance-expectations.html#mandatory-elements) and [must support](http://build.fhir.org/ig/HL7/US-Core/conformance-expectations.html#must-support-elements) core elements, extensions, vocabularies and value sets which SHALL be present in the Group resource when using this profile.

 ## Mandatory and Must Support Data Elements

  The following data-elements are mandatory (i.e data MUST be present) or must be supported if the data is present in the source system. They are presented below in a simple human-readable explanation.  Profile specific guidance and examples are provided as well.  The StructureDefinition and its rendering provides a summary, tree views, definitions, and terminology requirements.

  **Each Group must have:**

  1.  a type of "person"
  1.  a actual marked as "true" to indicate it a list of real patients

  **Each Group must support:**

  1. The [Argonaut Patient List Questionnaire Extension](/RgP-iegaTASWxO00CKXeEA?both)
  1. the number of members in the patient list
  1. A reference to the practitioner or organization managing the list*
  1. One or more characteristic codes that define the patient list
  1. One or more references to the patients who make up the patient list
  1. The [Argonaut Patient List  Member QuestionnaireResponse Extension](/nswM55USQZWXERNSqBxBug)
  1. The [Argonaut Patient List Member Appointment Extension](/ftDJ06TPRnSTCIr2fBPBpQ)
  1. The [Argonaut Patient List Member Encounter Extension](/pLpthchtTGWjt4hqLwU8Kg)

## Profile specific implementation guidance:

  * \* The `managingEntity` element differentiates between user-maintained and system-maintained lists.  Additionally, the [Provenance](http://hl7.org/fhir/provenance.html) resource could be used to provide more details about patient list creation and management.
  * Group with different characteristics can be combined to create a union of characteristic, for example a group of patients at location = Location1 or Location2 or a group of patients at location = Location1 or Practitioner = Practitioner2
  * This profile restricts the references to the practitioner or organization managing the list and the patients who make up the patient list to FHIR resource ids.  Providing *only* a business or other identifier as a logical reference to the entity of the target resource is not supported.

## Formal Definition
Rendered output [ArgonautPatientListProfile](https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist.html#profile)


<iframe src="https://argonautproject.github.io/patient-lists/StructureDefinition-patientlist.html#profile" width="100%" height="500">
</iframe>

YAML representation of the argo-patientlist resource profile.

{%gist Healthedata1/5ae0c565e4d7050cebf478f9e7f493ae%}


## Examples

- [Example 1](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 2](/u8iAyzZ0SGahQdbVzYpfoQ)
- [Example 3](/u8iAyzZ0SGahQdbVzYpfoQ)

{%hackmd 4AMMqV_dQqmCrx1yZibv7Q %}