### Argonaut Patient List FHIR artifacts

This Implementation Guide defines and renders the [Argonaut Patient List FHIR Artifacts](artifacts.html)

this is a stub for a future Implementation Guide.
